<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\wamp64\www\task\lighthouse-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>