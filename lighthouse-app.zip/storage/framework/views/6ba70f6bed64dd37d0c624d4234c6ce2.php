<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\task\lighthouse-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>