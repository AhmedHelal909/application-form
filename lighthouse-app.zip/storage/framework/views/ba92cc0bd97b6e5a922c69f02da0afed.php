<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name', 'Lighthouse App')); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Styles (Breeze uses Tailwind by default) -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        body {
            font-family: 'Nunito', sans-serif;
            background: #f9fafb;
            min-height: 100vh;
        }
        nav {
            background: #2563eb;
            color: #fff;
        }
        nav a {
            color: #fff;
            margin-right: 15px;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 700px;
            margin: 30px auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
    </style>

    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>

    <nav class="p-4 flex justify-between items-center">
        <div>
            <a href="<?php echo e(url('/')); ?>"><strong><?php echo e(config('app.name', 'Lighthouse App')); ?></strong></a>
        </div>

        <div>
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>
                <a href="<?php echo e(route('register')); ?>">Register</a>
            <?php else: ?>
                <span>Hello, <?php echo e(Auth::user()->name); ?></span>
                <a href="<?php echo e(route('applications.create')); ?>">Submit Application</a>
                <form class="inline" method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="background:none;border:none;color:white;cursor:pointer;">Logout</button>
                </form>
            <?php endif; ?>
        </div>
    </nav>

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\task\lighthouse-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>