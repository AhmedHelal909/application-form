<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Application #<?php echo e($application->id); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        h1 { text-align:center; }
        .field { margin-bottom: 6px; }
    </style>
</head>
<body>
    <h1>Application #<?php echo e($application->id); ?></h1>
    <div class="field"><strong>Name:</strong> <?php echo e($user->name); ?></div>
    <div class="field"><strong>Email:</strong> <?php echo e($application->contact_email); ?></div>
    <div class="field"><strong>Phone:</strong> <?php echo e($application->contact_phone); ?></div>
    <div class="field"><strong>DOB:</strong> <?php echo e($application->date_of_birth ?? '—'); ?></div>
    <div class="field"><strong>Gender:</strong> <?php echo e($application->gender ?? '—'); ?></div>
    <div class="field"><strong>Country:</strong> <?php echo e($application->country ?? '—'); ?></div>
    <div class="field"><strong>Comments:</strong><div><?php echo e($application->comments); ?></div></div>

    <?php if($application->files && count($application->files)): ?>
        <h3>Files</h3>
        <ul>
        <?php $__currentLoopData = $application->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e(basename($f)); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\task\lighthouse-app\resources\views/applications/pdf.blade.php ENDPATH**/ ?>