<?php $__env->startComponent('mail::message'); ?>
# New Application Submitted

A new application has been submitted by **<?php echo e($user->name); ?>**.

**Contact Email:** <?php echo e($application->contact_email); ?>  
**Contact Phone:** <?php echo e($application->contact_phone); ?>  
**Country:** <?php echo e($application->country ?? '—'); ?>  
**DOB:** <?php echo e($application->date_of_birth ?? '—'); ?>  
**Gender:** <?php echo e($application->gender ?? '—'); ?>


---

### 📎 Uploaded Files:
<?php if($application->files && count($application->files)): ?>
<?php $__currentLoopData = $application->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- [<?php echo e(basename($file)); ?>](<?php echo e(asset('storage/' . $file)); ?>)
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
_No files uploaded._
<?php endif; ?>

---

Thanks,  
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\task\lighthouse-app\resources\views/emails/application/submitted.blade.php ENDPATH**/ ?>